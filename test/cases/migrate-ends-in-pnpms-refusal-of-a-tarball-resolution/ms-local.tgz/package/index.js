module.exports = function ms(value) { return value; };
